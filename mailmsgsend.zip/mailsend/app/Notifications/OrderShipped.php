<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\NexmoMessage;
use Illuminate\Notifications\Notification;
use Nexmo\Laravel\Facade\Nexmo;

class OrderShipped extends Notification
{
    use Queueable;
    private $enrollment;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($enrollment)
    {
        $this->enrollment = $enrollment;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail','nexmo'];
    }

    /** 
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    // public function toMail($notifiable)              //it's use for send mail
    // {
    //     return (new MailMessage)
    //                 ->line('hello ravi this is mail massage.')
    //                 ->action('Notification Action', url('/'))
    //                 ->line('Thank you for using our application!');
    // }

     public function toMail($notifiable)              //it's use for send mail
    {
        return (new MailMessage)
                    ->line($this->enrollment['body'])
                    ->action($this->enrollment['enrollmetText'], $this->enrollment['url'])
                    ->line($this->enrollment['thankyou']);
    }

    // public function toNexmo($notifiable)
    // {
    //     return (new NexmoMessage())
    //         ->content('order has been shiped');
    // }


    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
