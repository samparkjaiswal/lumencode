<?php $__env->startComponent('mail::message'); ?>
# Welcome <?php echo e($name); ?>


This is Test Massage

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Button Text
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /opt/lampp/htdocs/mailsend/resources/views/emails/markdown.blade.php ENDPATH**/ ?>