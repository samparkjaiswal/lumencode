<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
// use DB;

use App\Models\CommonModel;




class StudentController extends Controller
{





    public function index()
    {
        echo "hello";
    }

    public function register(Request $request)
    {
        $insert =  DB::table('students')->insert([

            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password
        ]);

        if($insert)
        {
            return response()->json('Data inserted', 200);
        }
        else
        {
            return response()->json('Something error! try after sometimes', 400);
        }
    }

    public function fetchdata()
    {
        $show = DB::table('students')->select('*')->get();
        if($show)
        {
            return response()->json($show, 200);
        }
        else
        {
            return response()->json('failed fetch', 400);
        }
    }

    public function fetchiddata($id)
    {
        $perdata = DB::table('students')->where('id', $id)->get();

        if($perdata)
        {
            return response()->json($perdata, 200);
        }
        else
        {
            return response()->json('something gone wrong!', 400);
        }
    }

    public function updatedata(Request $request, $id)
    {

        $getrecord = DB::table('students')->where('id', $id)->get();



        $updaterecord = DB::table('students')->where('id', $id)->update([
            'name'=> $request->name,
            'email'=> $request->email
        ]);

        if($updaterecord)
        {
            return response()->json('Record Update', 200);
        }
        else
        {
            return response()->json('something wrong! try after sometimes', 400);
        }

    }




}
