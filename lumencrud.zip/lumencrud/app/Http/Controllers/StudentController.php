<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
// use DB;




class StudentController extends Controller
{
    public function index()
    {
        echo "hello";
    }

//     public function register(Request $request)
//     {
//         DB::table('students')->insert([

//         ]);
//     }
}
